using Dapper;
using TaskTracker.Data;
using TaskTracker.Models;

namespace TaskTracker.Repositories;

public class ProjectRepository
{
    private readonly IDbConnectionFactory _factory;

    public ProjectRepository(IDbConnectionFactory factory) => _factory = factory;

    public async Task<Project> CreateAsync(string name, int ownerId, string[] tags, string settingsJson)
    {
        using var conn = _factory.Create();
        return await conn.QuerySingleAsync<Project>(@"
            INSERT INTO projects (name, owner_id, tags, settings)
            VALUES (@Name, @OwnerId, @Tags, @Settings::jsonb)
            RETURNING *",
            new { Name = name, OwnerId = ownerId, Tags = tags, Settings = settingsJson });
    }

    public async Task<List<Project>> GetByTagAsync(string tag)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<Project>(
            "SELECT * FROM projects WHERE @Tag = ANY(tags) ORDER BY id",
            new { Tag = tag })).ToList();
    }

 public async Task<Project?> GetWithTasksAsync(int projectId)
{
    using var conn = _factory.Create();
    
    // 1. Получаем сам проект отдельным запросом (это надежно)
    var project = await conn.QuerySingleOrDefaultAsync<Project>(
        "SELECT * FROM projects WHERE id = @Id", 
        new { Id = projectId });

    if (project is null) 
        return null;

    // 2. Получаем задачи для этого проекта
    var tasks = await conn.QueryAsync<TaskItem>(
        "SELECT * FROM tasks WHERE project_id = @ProjectId ORDER BY id", 
        new { ProjectId = projectId });

    // 3. Привязываем задачи к проекту
    project.Tasks = tasks.ToList();

    return project;
}

    public async Task<(List<Project> Items, int Total)> GetPageAsync(int page, int pageSize)
    {
        using var conn = _factory.Create();
        var offset = (page - 1) * pageSize;

        using var multi = await conn.QueryMultipleAsync(@"
            SELECT COUNT(*) FROM projects;
            SELECT * FROM projects ORDER BY id LIMIT @Limit OFFSET @Offset;",
            new { Limit = pageSize, Offset = offset });

        var total = await multi.ReadSingleAsync<int>();
        var items = (await multi.ReadAsync<Project>()).ToList();

        return (items, total);
    }
}