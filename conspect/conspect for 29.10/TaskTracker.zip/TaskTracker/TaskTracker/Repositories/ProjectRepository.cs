using Dapper;
using TaskTracker.Data;
using TaskTracker.Models;

namespace TaskTracker.Repositories;

public class ProjectRepository
{
    private readonly IDbConnectionFactory _factory;

    public ProjectRepository(IDbConnectionFactory factory) => _factory = factory;

    public async Task<Project> CreateAsync(string name, int ownerId, string[] tags, string settingsJson)
    {
        using var conn = _factory.Create();
        return await conn.QuerySingleAsync<Project>(@"
            INSERT INTO projects (name, owner_id, tags, settings)
            VALUES (@Name, @OwnerId, @Tags, @Settings::jsonb)
            RETURNING *",
            new { Name = name, OwnerId = ownerId, Tags = tags, Settings = settingsJson });
    }

    public async Task<List<Project>> GetByTagAsync(string tag)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<Project>(
            "SELECT * FROM projects WHERE @Tag = ANY(tags) ORDER BY id",
            new { Tag = tag })).ToList();
    }

 public async Task<Project?> GetWithTasksAsync(int projectId)
{
    using var conn = _factory.Create();
    
    // 1. Получаем сам проект отдельным запросом (это надежно)
    var project = await conn.QuerySingleOrDefaultAsync<Project>(
        "SELECT * FROM projects WHERE id = @Id", 
        new { Id = projectId });

    if (project is null) 
        return null;

    // 2. Получаем задачи для этого проекта
    var tasks = await conn.QueryAsync<TaskItem>(
        "SELECT * FROM tasks WHERE project_id = @ProjectId ORDER BY id", 
        new { ProjectId = projectId });

    // 3. Привязываем задачи к проекту
    project.Tasks = tasks.ToList();

    return project;
}

   public async Task<(List<Project> Items, int Total)> GetPageAsync(int page, int pageSize)
    {
        using var conn = _factory.Create();
        var offset = (page - 1) * pageSize;

        using var multi = await conn.QueryMultipleAsync(@"
            SELECT COUNT(*) FROM projects;
            SELECT * FROM projects ORDER BY id LIMIT @Limit OFFSET @Offset;",
            new { Limit = pageSize, Offset = offset });

        var total = await multi.ReadSingleAsync<int>();
        var items = (await multi.ReadAsync<Project>()).ToList();

        return (items, total);
    }
// Для второго ззадания в самостоятельной
        public async Task UpdateSettingsAsync(int id, string jsonPatch)
    {
        using var conn = _factory.Create();
        await conn.ExecuteAsync(
            "UPDATE projects SET settings = settings || @Patch::jsonb WHERE id = @Id",
            new { Id = id, Patch = jsonPatch });
    }
// Для третьего ззадания в самостоятельной
      public async Task<List<Project>> GetPageKeysetAsync(int lastId, int limit)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<Project>(
            "SELECT * FROM projects WHERE id > @LastId ORDER BY id LIMIT @Limit",
            new { LastId = lastId, Limit = limit })).ToList();
    }
// Для пятого ззадания в самостоятельной
        public async Task<List<Project>> GetManyWithTasksAsync()
    {
        using var conn = _factory.Create();
        var dict = new Dictionary<int, Project>();
        await conn.QueryAsync<Project, TaskItem, Project>(@"
            SELECT p.id, p.name, p.owner_id, p.tags, p.settings, p.created_at,
                   t.id AS task_id, t.project_id AS task_project_id,
                   t.title AS task_title, t.is_done AS task_is_done,
                   t.due_date AS task_due_date, t.metadata AS task_metadata,
                   t.created_at AS task_created_at
            FROM projects p
            LEFT JOIN tasks t ON t.project_id = p.id
            ORDER BY p.id, t.id",
            (project, task) =>
            {
                if (!dict.TryGetValue(project.Id, out var current))
                {
                    current = project;
                    current.Tasks = new List<TaskItem>();
                    dict.Add(current.Id, current);
                }
                if (task is not null && task.Id != 0)
                    current.Tasks.Add(task);
                return current;
            },
            splitOn: "task_id");
        return dict.Values.ToList();
    }
// Для шестого ззадания в самостоятельной
     public async Task<Project> CreateWithKickoffAsync(string name, int ownerId, string[] tags, string settingsJson)
    {
        using var conn = _factory.Create();
        await conn.OpenAsync();
        await using var tx = await conn.BeginTransactionAsync();
        try
        {
            var project = await conn.QuerySingleAsync<Project>(@"
                INSERT INTO projects (name, owner_id, tags, settings)
                VALUES (@Name, @OwnerId, @Tags, @Settings::jsonb) RETURNING *",
                new { Name = name, OwnerId = ownerId, Tags = tags, Settings = settingsJson }, tx);

            await conn.ExecuteAsync(
                "INSERT INTO tasks (project_id, title) VALUES (@ProjectId, 'Kickoff')",
                new { ProjectId = project.Id }, tx);

            await tx.CommitAsync();
            return project;
        }
        catch
        {
            await tx.RollbackAsync();
            throw;
        }
    }
}