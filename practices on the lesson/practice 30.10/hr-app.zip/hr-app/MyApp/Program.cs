using System.Data;
using System.Diagnostics;
using Dapper;
using Npgsql;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// строка подключения берётся из docker-compose.yml (environment: CONN_STRING)
string cs = Environment.GetEnvironmentVariable("CONN_STRING")!;


// настройка маппинга из Dapper.md пункт 2
// В этой задаче колонки однословные (id, name, salary, department), но если добавить dep_id / created_at — Dapper без этого не замапит.
Dapper.DefaultTypeMap.MatchNamesWithUnderscores = true;

// Эндпоинт 1: GET /parallel
// Каркас из async-npgsql.md 3.1 (await using), 3.2 (OpenAsync), и 4.2 (ExecuteScalarAsync)
// Task.WhenAll и Stopwatch новые, они из .NET 
app.MapGet("/parallel", async () =>
{
    var sw = Stopwatch.StartNew(); // для замера времени


    // два соединения из пула (Pooling=true в CONN_STRING)
    // 3.1 - await using, чтобы Dispose не блокировал поток
    await using var conn1 = new NpgsqlConnection(cs); // 3.1 await using
    await using var conn2 = new NpgsqlConnection(cs);
    await conn1.OpenAsync();  // 3.2
    await conn2.OpenAsync();

// 4.1
    await using var cmd1 = new NpgsqlCommand(
        "SELECT COUNT(*) FROM employees", conn1);
    await using var cmd2 = new NpgsqlCommand(
        "SELECT COUNT(*) FROM departments", conn2);

// 4.2
    var t1 = cmd1.ExecuteScalarAsync(); 
    var t2 = cmd2.ExecuteScalarAsync(); 
   
    await Task.WhenAll(t1, t2);    // сам

    sw.Stop();

// из 4.2 - но скаляр надо привести к нужному типу.
    return Results.Ok(new
    {
        employees   = (long)(await t1)!,
        departments = (long)(await t2)!,
        elapsedMs = sw.ElapsedMilliseconds   // с замером времени» из билета
    });
});



// 2. /raise
/// Шаблрон взял из: async-npgsql.md 4.5 (транзакция) + 4.1 (ExecuteNonQuery)
//  Dapper.md 13 — та же логика транзакции
app.MapPost("/raise", async (Raise r) =>
{
    await using var conn = new NpgsqlConnection(cs); // 3.1
    await conn.OpenAsync();

    //4.5  BeginTransactionAsync
    await using var tx = await conn.BeginTransactionAsync();   // 4.5

    try
    {
         // параметры @delta или @depId — это тема параметры из билета
        // конкатенация строк была бы SQL-инъекцией
        await using var cmd = new NpgsqlCommand(
            "UPDATE employees SET salary = salary + @delta WHERE dep_id = @depId",
            conn, tx); // tx в конструктор
        cmd.Parameters.AddWithValue("@delta", r.Delta);
        cmd.Parameters.AddWithValue("@depId", r.DepId);

// 4.1 ExecuteNonQueryAsync возвращает число затронутых строк
        int affected = await cmd.ExecuteNonQueryAsync();   
        await tx.CommitAsync();
        return Results.Ok(new { affected });
    }
       
        // 4.5 
        catch
{
            await tx.RollbackAsync();
             throw;
}
    
});

// ЭНДПОИНТ 3: GET /employees
// База: Dapper.md §3.1 (QueryAsync), §10 (multi-mapping при JOIN)
app.MapGet("/employees", async () =>
{
    // §3.1 - здесь using (не await using), потому что Dapper сам откроет и закроет соединение. DisposeAsync не нужен.
    using var conn = new NpgsqlConnection(cs);

    // §3.1 - QueryAsync<T> с параметрами (у нас их нет), Dapper сам мапит колонки id/name/salary/department
    // на record Employee(Id, Name, Salary, Department)
    var list = await conn.QueryAsync<Employee>(
        @"SELECT e.id, e.name, e.salary, d.name AS department
          FROM employees e
          JOIN departments d ON d.id = e.dep_id
          ORDER BY e.id");

    return Results.Ok(list);
});


// ЭНДПОИНТ 4: GET /employees/table
// Темы: DataSet, DataAdapter, DataTable, DataTable.Select
// В конспектах этого нету - написано по классическому шаблону ADO.NET
app.MapGet("/employees/table", () =>
{
      // здесь using (синхронный), потому что NpgsqlDataAdapter.Fill — синхронный метод. Async-версии у DataAdapter нет.
    using var conn = new NpgsqlConnection(cs);
    conn.Open();

  // DataAdapter сам выполнит SQL и заполнит DataSet
    using var adapter = new NpgsqlDataAdapter(
        @"SELECT e.id, e.name, e.salary, d.name AS department
          FROM employees e
          JOIN departments d ON d.id = e.dep_id", conn);

// DataSet - контейнер, внутри будет DataTable employees
    var ds = new DataSet();
    adapter.Fill(ds, "employees");
    var table = ds.Tables["employees"]!;


    // требование билета: фильтрация через DataTable.Select. строка фильтра - как WHERE, но на стороне DataTable
    var highPaid = table.Select("salary > 75000");



    static object[] Map(DataRow row) => new object[]
    {
        row.Field<int>("id"),
        row.Field<string>("name")!,
        row.Field<decimal>("salary"),
        row.Field<string>("department")!
    };

    return Results.Ok(new
    {
        total = table.Rows.Count, // сколько всего 
        all = table.Rows.Cast<DataRow>().Select(Map), // все строки 
        highPaid = highPaid.Select(Map) // только больше 75000
    });
});

app.Run();

// DTO-модели
record Raise(int DepId, decimal Delta);
record Employee(int Id, string Name, decimal Salary, string Department);