CREATE TABLE departments (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL);
CREATE TABLE employees (
    id SERIAL PRIMARY KEY,
    dep_id INT REFERENCES departments(id),
    name VARCHAR(100) NOT NULL,
    salary NUMERIC(10,2) NOT NULL
);
INSERT INTO departments (name) VALUES ('IT'), ('HR');
INSERT INTO employees (dep_id, name, salary) VALUES
    (1, 'Иван', 80000),
    (2, 'Мария', 70000);