using Npgsql;

namespace NpgsqlPractice;

public static class Db
{
    public const string ConnectionString =
        "Host=localhost;Port=5432;Database=npgsql_tasks;Username=postgres;Password=112;" +
        "Maximum Pool Size=20;Timeout=15";

    public static NpgsqlConnection Create() => new(ConnectionString);
}