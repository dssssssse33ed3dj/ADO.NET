using Npgsql;
using NpgsqlPractice;

namespace NpgsqlPractice.Tasks;

public sealed record Employee(int Id, string FirstName, string LastName,
                             string? Email, decimal? Salary, DateTime HiredAt);

public static class Task01_Employees
{
    public static async Task RunAsync(CancellationToken userToken)
    {
        var list = await GetEmployeesAsync(page: 1, pageSize: 10, userToken);
        Console.WriteLine($"Страница 1: {list.Count} сотрудников");
        foreach (var e in list)
            Console.WriteLine($"  {e.Id,3}  {e.FirstName,-10} {e.LastName,-10} {e.Salary,12:F2}");
    }

    public static async Task<List<Employee>> GetEmployeesAsync(
        int page, int pageSize, CancellationToken userToken)
    {
        using var linked = CancellationTokenSource.CreateLinkedTokenSource(userToken);
        linked.CancelAfter(TimeSpan.FromSeconds(15));

        var result = new List<Employee>();

        await using var conn = Db.Create();
        await conn.OpenAsync(linked.Token).ConfigureAwait(false);

        await using var cmd = new NpgsqlCommand(
            "SELECT id, first_name, last_name, email, salary, hired_at " +
            "FROM employees ORDER BY id LIMIT @limit OFFSET @offset", conn)
        {
            CommandTimeout = 10
        };
        cmd.Parameters.AddWithValue("limit", pageSize);
        cmd.Parameters.AddWithValue("offset", (page - 1) * pageSize);

        try
        {
            await using var reader = await cmd.ExecuteReaderAsync(linked.Token).ConfigureAwait(false);
            while (await reader.ReadAsync(linked.Token).ConfigureAwait(false))
            {

                result.Add(new Employee(
                    reader.GetInt32(0), reader.GetString(1), reader.GetString(2),
                    reader.IsDBNull(3) ? null : reader.GetString(3),
                    reader.IsDBNull(4) ? null : reader.GetDecimal(4),
                    reader.GetDateTime(5)));
            }
            return result;
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("Отменено (userToken или CancelAfter 15s)");
            throw;
        }
        catch (PostgresException pg) when (pg.SqlState == "57014")
        {
            Console.WriteLine("Серверная отмена (57014) — соединение сохранено");
            throw;
        }
    }
}