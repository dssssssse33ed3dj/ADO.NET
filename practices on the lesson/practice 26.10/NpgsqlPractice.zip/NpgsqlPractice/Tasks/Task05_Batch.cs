using System.Diagnostics;
using Npgsql;
using NpgsqlPractice;

namespace NpgsqlPractice.Tasks;

public class ReportData
{
public List<(int Id, decimal Amount)> Orders { get; set; } = new();
public List<(int OrderId, string Name, decimal Price)> Items { get; set; } = new();
public decimal Total { get; set; }
}

public static class Task05_Batch
{
public static async Task RunAsync(CancellationToken token)
{
    var report = await BuildReportAsync(1, token);
    Console.WriteLine($"Заказы customer=1: {report.Orders.Count}");
    Console.WriteLine($"Позиции: {report.Items.Count}");
    Console.WriteLine($"Сумма: {report.Total:F2}");

    Console.WriteLine("\nСравнение 3 запросов:");
    await CompareAsync(token);
}

    public static async Task<ReportData> BuildReportAsync(int customerId, CancellationToken token)
    {
        await using var conn = Db.Create();
        await conn.OpenAsync(token);
        await using var batch = new NpgsqlBatch(conn);

        var c1 = new NpgsqlBatchCommand("SELECT id, amount FROM orders WHERE customer_id=@cid ORDER BY id");
        c1.Parameters.AddWithValue("cid", customerId);
        batch.BatchCommands.Add(c1);

        var c2 = new NpgsqlBatchCommand(
            "SELECT o.id, p.name, p.price FROM orders o " +
            "JOIN products p ON p.id = (o.id % 30) + 1 " +
            "WHERE o.customer_id=@cid ORDER BY o.id");
        c2.Parameters.AddWithValue("cid", customerId);
        batch.BatchCommands.Add(c2);

        var c3 = new NpgsqlBatchCommand("SELECT COALESCE(SUM(amount),0) FROM orders WHERE customer_id=@cid");
        c3.Parameters.AddWithValue("cid", customerId);
        batch.BatchCommands.Add(c3);

        var report = new ReportData();
        await using var reader = await batch.ExecuteReaderAsync(token);

        while (await reader.ReadAsync(token))
            report.Orders.Add((reader.GetInt32(0), reader.GetDecimal(1)));

        await reader.NextResultAsync(token);
        while (await reader.ReadAsync(token))
            report.Items.Add((reader.GetInt32(0), reader.GetString(1), reader.GetDecimal(2)));

        await reader.NextResultAsync(token);
        if (await reader.ReadAsync(token)) report.Total = reader.GetDecimal(0);

        return report;
    }

    static async Task CompareAsync(CancellationToken token)
    {
        string[] queries =
        {
            "SELECT count(*) FROM orders",
            "SELECT count(*) FROM employees",
            "SELECT count(*) FROM products"
        };
        var sw = Stopwatch.StartNew();

        // Вариант 1: NpgsqlBatch — 1 round-trip, команды последовательно
        await using (var conn = Db.Create())
        {
            await conn.OpenAsync(token);
            await using var batch = new NpgsqlBatch(conn);
            foreach (var q in queries) batch.BatchCommands.Add(new NpgsqlBatchCommand(q));
            await using var r = await batch.ExecuteReaderAsync(token);
            do { while (await r.ReadAsync(token)) { } }
            while (await r.NextResultAsync(token));
        }
        Console.WriteLine($"  Batch (1 соединение):          {sw.ElapsedMilliseconds} ms");

        // Вариант 2: три отдельных запроса на одном соединении
        sw.Restart();
        await using (var conn = Db.Create())
        {
            await conn.OpenAsync(token);
            foreach (var q in queries)
            {
                await using var cmd = new NpgsqlCommand(q, conn);
                await cmd.ExecuteScalarAsync(token);
            }
        }
        Console.WriteLine($"  3 запроса на 1 conn (посл.):   {sw.ElapsedMilliseconds} ms");

        // Вариант 3: три запроса параллельно на трёх соединениях
        sw.Restart();
        var tasks = new List<Task>();
        foreach (var q in queries)
        {
            tasks.Add(Task.Run(async () =>
            {
                await using var conn = Db.Create();
                await conn.OpenAsync(token);
                await using var cmd = new NpgsqlCommand(q, conn);
                await cmd.ExecuteScalarAsync(token);
            }));
        }
        await Task.WhenAll(tasks);
        Console.WriteLine($"  3 запроса на 3 conn (парал.):  {sw.ElapsedMilliseconds} ms");
    }
}