using System.Data;
using Npgsql;
using NpgsqlPractice;

namespace NpgsqlPractice.Tasks;

public static class Task04_Export
{
    public static async Task RunAsync(CancellationToken token)
    {
        var dir = Path.Combine(AppContext.BaseDirectory, "output");
        Directory.CreateDirectory(dir);
        await ExportDocumentsAsync(dir, token);

        Console.WriteLine("\nВыгруженные файлы:");
        foreach (var f in Directory.GetFiles(dir))
            Console.WriteLine($"  {Path.GetFileName(f)}  {new FileInfo(f).Length} байт");
    }

    public static async Task ExportDocumentsAsync(string outputDir, CancellationToken token)
    {
        await using var conn = Db.Create();
        await conn.OpenAsync(token);

        await using var cmd = new NpgsqlCommand(
            "SELECT id, file_name, content FROM documents ORDER BY id", conn);

        await using var reader = await cmd.ExecuteReaderAsync(CommandBehavior.SequentialAccess, token);

        while (await reader.ReadAsync(token))
        {
            int id = reader.GetInt32(0);
            string name = reader.GetString(1);
            byte[] content = await reader.GetFieldValueAsync<byte[]>(2, token);

            string path = Path.Combine(outputDir, $"{id:D2}_{name}");
            await using var fs = new FileStream(path, FileMode.Create, FileAccess.Write,
                FileShare.None, 81920, FileOptions.Asynchronous);
            await fs.WriteAsync(content, token);
            Console.WriteLine($"  {path}  ({content.Length} байт)");
        }
    }
}