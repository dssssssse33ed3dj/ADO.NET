using System.Diagnostics;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Npgsql;

namespace NpgsqlPractice.Tasks;

public class DatabaseHealthCheck : IHealthCheck
{
    readonly string _cs;
    public DatabaseHealthCheck(string cs) { _cs = cs; }

    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken ct = default)
    {
    
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(TimeSpan.FromSeconds(3));

var sw = Stopwatch.StartNew();
    try
    {
        await using var conn = new NpgsqlConnection(_cs);
        await conn.OpenAsync(cts.Token);

        await using (var setCmd = new NpgsqlCommand("SET statement_timeout = '2000ms'", conn))
            await setCmd.ExecuteNonQueryAsync(cts.Token);

        await using (var pingCmd = new NpgsqlCommand("SELECT 1", conn))
            await pingCmd.ExecuteScalarAsync(cts.Token);

        sw.Stop();
        var data = new Dictionary<string, object> { ["time_ms"] = sw.ElapsedMilliseconds };
        if (sw.ElapsedMilliseconds > 1000)
            return HealthCheckResult.Degraded($"Медленно {sw.ElapsedMilliseconds} мс", data: data);
        return HealthCheckResult.Healthy($"OK {sw.ElapsedMilliseconds} мс", data);
    }
    catch (PostgresException ex) when (ex.SqlState == "57014")
    {
        return HealthCheckResult.Unhealthy(
            $"Сработал statement_timeout за {sw.ElapsedMilliseconds} мс", ex);
    }
    catch (OperationCanceledException)
    {
        return HealthCheckResult.Unhealthy(
            $"Сработал CancelAfter за {sw.ElapsedMilliseconds} мс");
    }
    catch (Exception ex)
    {
        return HealthCheckResult.Unhealthy($"Ошибка: {ex.Message}", ex);
    }
}
}

public static class Task07_HealthCheck
{
    public static async Task RunAsync(CancellationToken token)
    {
        string cs =
            "Host=localhost;Port=5432;Database=npgsql_tasks;Username=postgres;Password=112;Timeout=5";

        var check = new DatabaseHealthCheck(cs);

        Console.WriteLine("1) Обычная проверка:");
        var ok = await check.CheckHealthAsync(null!, token);
        Console.WriteLine($"   {ok.Status} — {ok.Description}");

        Console.WriteLine("\n2) Проверка с 'зависшим' запросом (pg_sleep(10)):");
        var slowCs = cs + ";Options=-c statement_timeout=2000";
        var sw = Stopwatch.StartNew();
        try
        {
            await using var conn = new NpgsqlConnection(slowCs);
            await conn.OpenAsync(token);
            await using (var setCmd = new NpgsqlCommand("SET statement_timeout='2000ms'", conn))
                await setCmd.ExecuteNonQueryAsync(token);
            await using (var sleepCmd = new NpgsqlCommand("SELECT pg_sleep(10)", conn))
                await sleepCmd.ExecuteScalarAsync(token);
        }
        catch (PostgresException ex) when (ex.SqlState == "57014")
        {
            sw.Stop();
            Console.WriteLine($"   Unhealthy — statement_timeout за {sw.ElapsedMilliseconds} мс");
        }

        Console.WriteLine("\n3) Неверный порт (сервер недоступен):");
        var badCheck = new DatabaseHealthCheck(
            "Host=localhost;Port=5999;Database=npgsql_tasks;Username=postgres;Password=112;Timeout=2");
        var down = await badCheck.CheckHealthAsync(null!, token);
        Console.WriteLine($"   {down.Status} — {down.Description}");
    }
}