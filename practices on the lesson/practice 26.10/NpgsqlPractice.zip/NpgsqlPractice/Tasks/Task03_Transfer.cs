using System.Data;
using Npgsql;
using NpgsqlPractice;

namespace NpgsqlPractice.Tasks;

public static class Task03_Transfer
{
public static async Task RunAsync(CancellationToken token)
{
    await ResetBalancesAsync(token);

    Console.WriteLine("До:");
    await PrintBalancesAsync(token);

    await TransferAsync(1, 2, 1000, token);
    Console.WriteLine("\nПосле перевода 1000:");
    await PrintBalancesAsync(token);

    // Отменяем через 50 мс — транзакция должна откатиться
    using var cts = new CancellationTokenSource(50);
    try { await TransferAsync(2, 1, 500, cts.Token); }
    catch (OperationCanceledException) { Console.WriteLine("\nПеревод отменён"); }

    Console.WriteLine("\nПосле отмены (балансы те же):");
    await PrintBalancesAsync(token);
}

public static async Task TransferAsync(int fromId, int toId, decimal amount, CancellationToken userToken)
{
    await using var conn = Db.Create();
    await conn.OpenAsync(userToken);
    
    await using var tx = await conn.BeginTransactionAsync(IsolationLevel.Serializable, userToken);

        try
{
            await LockRowAsync(conn, tx, fromId, userToken);
            await LockRowAsync(conn, tx, toId, userToken);

            await using (var cmd = new NpgsqlCommand(
                "UPDATE accounts SET balance = balance - @a WHERE id = @id", conn, tx))
            {
                cmd.Parameters.AddWithValue("a", amount);
                cmd.Parameters.AddWithValue("id", fromId);
                await cmd.ExecuteNonQueryAsync(userToken);
            }

            await using (var cmd = new NpgsqlCommand(
                "UPDATE accounts SET balance = balance + @a WHERE id = @id", conn, tx))
            {
                cmd.Parameters.AddWithValue("a", amount);
                cmd.Parameters.AddWithValue("id", toId);
                await cmd.ExecuteNonQueryAsync(userToken);
            }

            await tx.CommitAsync(userToken);
            Console.WriteLine($"Перевод {amount} с {fromId} на {toId} выполнен");
        }
        catch
        {
          
            try
            {
                await tx.RollbackAsync(CancellationToken.None);
            }
            catch (Exception rbEx)
            {
                throw new AggregateException("Rollback тоже упал", rbEx);
            }
            throw;
        }
    }

    static async Task LockRowAsync(NpgsqlConnection conn, NpgsqlTransaction tx, int id, CancellationToken t)
    {
        await using var cmd = new NpgsqlCommand(
            "SELECT balance FROM accounts WHERE id=@id FOR UPDATE", conn, tx);
        cmd.Parameters.AddWithValue("id", id);
        await cmd.ExecuteScalarAsync(t);
    }

    static async Task ResetBalancesAsync(CancellationToken token)
    {
        await using var c = Db.Create();
        await c.OpenAsync(token);
        await using var cmd = new NpgsqlCommand(
            "UPDATE accounts SET balance = CASE id WHEN 1 THEN 10000 WHEN 2 THEN 5000 END", c);
        await cmd.ExecuteNonQueryAsync(token);
    }

    static async Task PrintBalancesAsync(CancellationToken token)
    {
        await using var conn = Db.Create();
        await conn.OpenAsync(token);
        await using var cmd = new NpgsqlCommand("SELECT id, owner_name, balance FROM accounts ORDER BY id", conn);
        await using var r = await cmd.ExecuteReaderAsync(token);
        while (await r.ReadAsync(token))
            Console.WriteLine($"  {r.GetInt32(0)} {r.GetString(1)} = {r.GetDecimal(2):F2}");
    }
}