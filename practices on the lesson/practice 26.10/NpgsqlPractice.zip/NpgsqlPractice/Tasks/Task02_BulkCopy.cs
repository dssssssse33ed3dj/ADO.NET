using System.Diagnostics;
using Npgsql;
using NpgsqlTypes;
using NpgsqlPractice;

namespace NpgsqlPractice.Tasks;

public sealed record Order(int Id, int CustomerId, decimal Amount, DateTimeOffset CreatedAt);

public static class Task02_BulkCopy
{
    public static async Task RunAsync(CancellationToken token)
    {
await ResetStagingAsync(token);
Console.WriteLine($"[До COPY] orders_staging: {await CountAsync(token)} строк");

var progress = new Progress<int>(n =>
{
    if (n % 100_000 == 0) Console.WriteLine($"  ... записано {n:N0}");
});
var sw = Stopwatch.StartNew();
await BulkCopyAsync(GenerateOrders(1_000_000), progress, token);
sw.Stop();
Console.WriteLine($"[После COPY] {await CountAsync(token)} строк за {sw.ElapsedMilliseconds} ms");

await ResetStagingAsync(token);
Console.WriteLine($"\n[Перед отменой] orders_staging: {await CountAsync(token)} строк");
using var cts = new CancellationTokenSource(300);
try { await BulkCopyAsync(GenerateOrders(1_000_000), null, cts.Token); }
catch (OperationCanceledException) { Console.WriteLine("Отменено на середине COPY"); }
Console.WriteLine($"[После отмены] orders_staging: {await CountAsync(token)} строк (должно быть 0)");
}

public static async Task BulkCopyAsync(
    IEnumerable<Order> orders, IProgress<int>? progress, CancellationToken token)
{
    await using var conn = Db.Create();
    await conn.OpenAsync(token);

    await using var importer = await conn.BeginBinaryImportAsync(
        "COPY orders_staging (id, customer_id, amount, created_at) " +
        "FROM STDIN (FORMAT BINARY)", token);

    int written = 0;
    foreach (var o in orders)
    {
            token.ThrowIfCancellationRequested();
            await importer.StartRowAsync(token);

            await importer.WriteAsync(o.Id, NpgsqlDbType.Integer, token);
            await importer.WriteAsync(o.CustomerId, NpgsqlDbType.Integer, token);
            await importer.WriteAsync(o.Amount, NpgsqlDbType.Numeric, token);
            await importer.WriteAsync(o.CreatedAt, NpgsqlDbType.TimestampTz, token);
            written++;
            if (written % 10_000 == 0) progress?.Report(written);
        }
        await importer.CompleteAsync(token);
    }

    static IEnumerable<Order> GenerateOrders(int count)
    {
        var now = DateTimeOffset.UtcNow;
        for (int i = 1; i <= count; i++)
            yield return new Order(i, (i % 10) + 1, (i % 10000) / 100m, now.AddSeconds(-i));
    }

    static async Task ResetStagingAsync(CancellationToken token)
    {
        await using var c = Db.Create();
        await c.OpenAsync(token);
        await using var cmd = new NpgsqlCommand(
            "DROP TABLE IF EXISTS orders_staging; " +
            "CREATE TABLE orders_staging (id INT, customer_id INT, " +
            "amount NUMERIC(12,2), created_at TIMESTAMPTZ);", c);
        await cmd.ExecuteNonQueryAsync(token);
    }

    static async Task<long> CountAsync(CancellationToken token)
    {
        await using var c = Db.Create();
        await c.OpenAsync(token);
        await using var cmd = new NpgsqlCommand("SELECT count(*) FROM orders_staging", c);
        return (long)(await cmd.ExecuteScalarAsync(token))!;
    }
}