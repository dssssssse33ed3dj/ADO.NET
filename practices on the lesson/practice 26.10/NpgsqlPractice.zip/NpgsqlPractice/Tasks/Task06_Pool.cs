using System.Diagnostics;
using Npgsql;
using NpgsqlPractice;

namespace NpgsqlPractice.Tasks;

public static class Task06_Pool
{
      const string Cs =
        "Host=localhost;Port=5432;Database=npgsql_tasks;Username=postgres;Password=112;" +
        "Maximum Pool Size=5;Timeout=5";

    // Сюда складываем соединения, чтобы они не закрывались 
    static readonly List<NpgsqlConnection> _held = new();

public static async Task RunAsync(CancellationToken token)
    {
_held.Clear();

Console.WriteLine("Занимаем 5 соединений:");
await ExhaustPoolAsync(5, token);

Console.WriteLine("\nПытаемся открыть 6-е:");
await DiagnosePoolAsync(token);

Console.WriteLine("\nЛечим:");
HealPool();

await using var conn = new NpgsqlConnection(Cs);
await conn.OpenAsync(token);
Console.WriteLine("Новое соединение успешно открылось");

await using var cmd = new NpgsqlCommand(
    "SELECT count(*) FROM pg_stat_activity WHERE datname = current_database()", conn);
var n = (long)(await cmd.ExecuteScalarAsync(token))!;
Console.WriteLine($"На сервере соединений: {n}");
}

    public static async Task ExhaustPoolAsync(int count, CancellationToken token)
    {
        for (int i = 0; i < count; i++)
        {
            var conn = new NpgsqlConnection(Cs);
            await conn.OpenAsync(token);
            _held.Add(conn);
            Console.WriteLine($"  занято {i + 1}/{count}");
        }
    }

    public static async Task DiagnosePoolAsync(CancellationToken token)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            await using var conn = new NpgsqlConnection(Cs);
            await conn.OpenAsync(token);
            Console.WriteLine("  открылось (пул не исчерпан)");
        }
        catch (NpgsqlException ex)
        {
            sw.Stop();
            Console.WriteLine($"  упало за {sw.ElapsedMilliseconds} мс");
            Console.WriteLine($"  {ex.Message}");
        }
    }

    public static void HealPool()
    {
        foreach (var c in _held) c.Dispose();
        _held.Clear();
        NpgsqlConnection.ClearAllPools();
        Console.WriteLine("  ClearAllPools выполнен");
    }
}