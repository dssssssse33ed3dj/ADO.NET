﻿using NpgsqlPractice.Tasks;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Console.WriteLine("Выбери задачу (цифра от 1 до 7):");
var choice = Console.ReadLine();

using var cts = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) => { cts.Cancel(); e.Cancel = true; };

try
{
    switch (choice)
    {
        case "1": await Task01_Employees.RunAsync(cts.Token); break;
        case "2": await Task02_BulkCopy.RunAsync(cts.Token); break;
        case "3": await Task03_Transfer.RunAsync(cts.Token); break;
        case "4": await Task04_Export.RunAsync(cts.Token); break;
        case "5": await Task05_Batch.RunAsync(cts.Token); break;
        case "6": await Task06_Pool.RunAsync(cts.Token); break;
        case "7": await Task07_HealthCheck.RunAsync(cts.Token); break;
        default:  Console.WriteLine("Нет такой задачи"); break;
    }
}
catch (OperationCanceledException) { Console.WriteLine("Отменено пользователем"); }