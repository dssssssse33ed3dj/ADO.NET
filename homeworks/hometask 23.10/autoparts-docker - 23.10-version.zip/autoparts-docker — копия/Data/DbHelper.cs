    using Npgsql;
    using AutoPartsApp.Models;

    namespace AutoPartsApp.Data;

    public class DbHelper
    {
        private readonly string _connectionString;

        public DbHelper(string connectionString)
        {
            _connectionString = connectionString;
        }

        // 1. Initialize() — Создание таблиц (DDL) и Начальные данные (Сидинг)
        public void Initialize()
        {
            using var connection = new NpgsqlConnection(_connectionString);
            connection.Open();

            // Создаем таблицу parts, если она отсутствует
            using (var createCmd = new NpgsqlCommand(@"
                CREATE TABLE IF NOT EXISTS parts (
                    id           SERIAL PRIMARY KEY,
                    name         VARCHAR(200) NOT NULL,
                    article      VARCHAR(50)  NOT NULL,
                    manufacturer VARCHAR(100) NOT NULL,
                    price        NUMERIC(18,2) NOT NULL,
                    stock        INTEGER NOT NULL DEFAULT 0,
                    description  VARCHAR(500)
                );", connection))
            {
                createCmd.ExecuteNonQuery();
            }

            // Создаем таблицу orders для Задачи №4, если она отсутствует
            using (var createOrdersCmd = new NpgsqlCommand(@"
                CREATE TABLE IF NOT EXISTS orders (
                    id           SERIAL PRIMARY KEY,
                    part_id      INTEGER NOT NULL,
                    quantity     INTEGER NOT NULL,
                    total        NUMERIC(18,2) NOT NULL,
                    created_at   TIMESTAMP NOT NULL DEFAULT NOW()
                );", connection))
            {
                createOrdersCmd.ExecuteNonQuery();
            }

            using var checkCmd = new NpgsqlCommand("SELECT COUNT(*) FROM parts", connection);
            var count = Convert.ToInt32(checkCmd.ExecuteScalar());

            if (count == 0)
            {
                using var seedCmd = new NpgsqlCommand(@"
                    INSERT INTO parts (name, article, manufacturer, price, stock, description) VALUES
                    ('Тормозная колодка', 'BC-1234', 'Bosch', 2500.00, 40, 'Передняя, для легковых авто'),
                    ('Масляный фильтр', 'OF-5678', 'Mann', 850.00, 120, 'Универсальный'),
                    ('Свеча зажигания', 'SP-9012', 'NGK', 450.00, 200, 'Иридиевая');", connection);
                seedCmd.ExecuteNonQuery();
            }

            // ЗАДАЧА №9
            try
            {
                using var constraintCmd = new NpgsqlCommand(
                    "ALTER TABLE parts ADD CONSTRAINT uq_parts_article UNIQUE (article);", 
                    connection);
                constraintCmd.ExecuteNonQuery();
            }
            catch (PostgresException ex) when (ex.SqlState == "42P16") 
            {
                // Игнорируем ошибку, если ограничение уже создано ранее
            }
        }

        // 2. Выборка всех деталей из базы
        public List<Part> GetAllParts()
        {
            var parts = new List<Part>();
            using var connection = new NpgsqlConnection(_connectionString);
            connection.Open();

            using var cmd = new NpgsqlCommand(
                "SELECT id, name, article, manufacturer, price, stock, description FROM parts ORDER BY id", 
                connection);
            
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                parts.Add(new Part
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Article = reader.GetString(2),
                    Manufacturer = reader.GetString(3),
                    Price = reader.GetDecimal(4),
                    Stock = reader.GetInt32(5),
                    Description = reader.IsDBNull(6) ? null : reader.GetString(6)
                });
            }
            return parts;
        }

        // 3. Поиск одной конкретной запчасти
        public Part? GetPartById(int id)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            connection.Open();

            using var cmd = new NpgsqlCommand(
                "SELECT id, name, article, manufacturer, price, stock, description FROM parts WHERE id = @id", 
                connection);
            cmd.Parameters.AddWithValue("@id", id);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return new Part
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Article = reader.GetString(2),
                    Manufacturer = reader.GetString(3),
                    Price = reader.GetDecimal(4),
                    Stock = reader.GetInt32(5),
                    Description = reader.IsDBNull(6) ? null : reader.GetString(6)
                };
            }
            return null; 
        }

        // 4. Безопасное добавление новой детали через INSERT
        public void AddPart(Part part)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            connection.Open();

            using var cmd = new NpgsqlCommand(@"
                INSERT INTO parts (name, article, manufacturer, price, stock, description)
                VALUES (@name, @article, @manufacturer, @price, @stock, @description);", connection);

            cmd.Parameters.AddWithValue("@name", part.Name);
            cmd.Parameters.AddWithValue("@article", part.Article);
            cmd.Parameters.AddWithValue("@manufacturer", part.Manufacturer);
            cmd.Parameters.AddWithValue("@price", part.Price);
            cmd.Parameters.AddWithValue("@stock", part.Stock);
            cmd.Parameters.AddWithValue("@description", (object?)part.Description ?? DBNull.Value);

            cmd.ExecuteNonQuery();
        }

        // 5. Покупка: уменьшение количества с проверкой остатка
        public bool DecreaseStock(int partId, int quantity)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            connection.Open();

            using var cmd = new NpgsqlCommand(@"
                UPDATE parts 
                SET stock = stock - @qty 
                WHERE id = @id AND stock >= @qty;", connection);

            cmd.Parameters.AddWithValue("@id", partId);
            cmd.Parameters.AddWithValue("@qty", quantity);

            return cmd.ExecuteNonQuery() > 0;
        }

        // ЗАДАЧА №1: Поиск по названию и артикулу
        public List<Part> SearchParts(string query)
        {
            var parts = new List<Part>();
            using var connection = new NpgsqlConnection(_connectionString);
            connection.Open();

            string sql = "SELECT id, name, article, manufacturer, price, stock, description FROM parts";
            if (!string.IsNullOrWhiteSpace(query))
            {
                sql += " WHERE name ILIKE @q OR article ILIKE @q";
            }
            sql += " ORDER BY id";

            using var cmd = new NpgsqlCommand(sql, connection);
            if (!string.IsNullOrWhiteSpace(query))
            {
                cmd.Parameters.AddWithValue("@q", $"%{query}%");
            }

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                parts.Add(new Part
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Article = reader.GetString(2),
                    Manufacturer = reader.GetString(3),
                    Price = reader.GetDecimal(4),
                    Stock = reader.GetInt32(5),
                    Description = reader.IsDBNull(6) ? null : reader.GetString(6)
                });
            }
            return parts;
        }

        // ЗАДАЧА №2: Удаление детали
        public bool DeletePart(int id)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            connection.Open();

            string sql = "DELETE FROM parts WHERE id = @id";
            using var cmd = new NpgsqlCommand(sql, connection);
            cmd.Parameters.AddWithValue("@id", id);

            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected > 0;
        }

        // ЗАДАЧА №3: Статистика по складу
        public (int totalParts, decimal totalValue, decimal avgPrice) GetStats()
        {
            using var connection = new NpgsqlConnection(_connectionString);
            connection.Open();

            string sql = "SELECT COUNT(*), COALESCE(SUM(price * stock), 0), COALESCE(AVG(price), 0) FROM parts";
            using var cmd = new NpgsqlCommand(sql, connection);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return (
                    totalParts: reader.GetInt32(0),
                    totalValue: reader.GetDecimal(1),
                    avgPrice: reader.GetDecimal(2)
                );
            }
            return (0, 0, 0);
        }

        // ЗАДАЧА №4: Оформление заказа в транзакции
        public bool PlaceOrder(int partId, int quantity)
        {
            using var connection = new NpgsqlConnection(_connectionString);
            connection.Open();

            using var tx = connection.BeginTransaction();
            try
            {
                string selectSql = "SELECT price, stock FROM parts WHERE id = @id";
                using var selectCmd = new NpgsqlCommand(selectSql, connection, tx);
                selectCmd.Parameters.AddWithValue("@id", partId);

                decimal price = 0;
                int stock = 0;
                using (var reader = selectCmd.ExecuteReader())
                {
                    if (!reader.Read()) { tx.Rollback(); return false; }
                    price = reader.GetDecimal(0);
                    stock = reader.GetInt32(1);
                }

                if (stock < quantity)
                {
                    tx.Rollback();
                    return false;
                }

                string insertOrderSql = "INSERT INTO orders (part_id, quantity, total) VALUES (@part_id, @qty, @total)";
                using var insertCmd = new NpgsqlCommand(insertOrderSql, connection, tx);
                insertCmd.Parameters.AddWithValue("@part_id", partId);
                insertCmd.Parameters.AddWithValue("@qty", quantity);
                insertCmd.Parameters.AddWithValue("@total", price * quantity);
                insertCmd.ExecuteNonQuery();

                string updatePartsSql = "UPDATE parts SET stock = stock - @qty WHERE id = @id";
                using var updateCmd = new NpgsqlCommand(updatePartsSql, connection, tx);

    updateCmd.Parameters.AddWithValue("@qty", quantity);
    updateCmd.Parameters.AddWithValue("@id", partId);
    updateCmd.ExecuteNonQuery();
    tx.Commit();
    return true;
    }
    catch
    {
    tx.Rollback();
    return false;
    }
    }
    // ЗАДАЧА №5: Массовое поступление товара с откатом (ПОЛНОСТЬЮ ПЕРЕПИСАН НА МАССИВ ТУПЛОВ)
    public bool Restock(System.ValueTuple<int, int>[] items)
    {
    using var connection = new NpgsqlConnection(_connectionString);
    connection.Open();
    using var tx = connection.BeginTransaction();
    try
    {
    string sql = "UPDATE parts SET stock = stock + @qty WHERE id = @id";
    foreach (var item in items)
    {
    using var cmd = new NpgsqlCommand(sql, connection, tx);
    cmd.Parameters.AddWithValue("@qty", item.Item2);
    cmd.Parameters.AddWithValue("@id", item.Item1);
    if (cmd.ExecuteNonQuery() == 0)
    {
    tx.Rollback();
    return false;
    }
    }
    tx.Commit();
    return true;
    }
    catch
    {
    tx.Rollback();
    return false;
    }
    }
    // ЗАДАЧА №6: "Сырое" чтение через NpgsqlDataReader
    public List<Dictionary<string, object?>> GetRawParts()
    {
    var result = new List<Dictionary<string, object?>>();
    using var connection = new NpgsqlConnection(_connectionString);
    connection.Open();
    using var cmd = new NpgsqlCommand("SELECT * FROM parts ORDER BY id", connection);
    using var reader = cmd.ExecuteReader();
    while (reader.Read())
    {
    var row = new Dictionary<string, object?>();
    for (int i = 0; i < reader.FieldCount; i++)
    {
    string columnName = reader.GetName(i);
    object? value = reader.IsDBNull(i) ? null : reader.GetValue(i);
    row.Add(columnName, value);
    }
    result.Add(row);
    }
    return result;
    }
    // ЗАДАЧА №7: DataTable через NpgsqlDataAdapter
    public System.Data.DataTable GetPartsDataTable()
    {
    var dt = new System.Data.DataTable();
    using var connection = new NpgsqlConnection(_connectionString);
    connection.Open();
    using var adapter = new NpgsqlDataAdapter("SELECT id, name, article, price, stock FROM parts ORDER BY id", connection);
    adapter.Fill(dt);
    return dt;
    }
    public System.Data.DataSet GetPartsDataSet()
    {
    var ds = new System.Data.DataSet();
    using var connection = new NpgsqlConnection(_connectionString);
    connection.Open();
    using var adapterParts = new NpgsqlDataAdapter("SELECT * FROM parts", connection);
    adapterParts.Fill(ds, "parts");
    using var adapterOrders = new NpgsqlDataAdapter("SELECT * FROM orders", connection);
    adapterOrders.Fill(ds, "orders");
    return ds;
    }
    // ЗАДАЧА №8: Асинхронная версия GetAllParts
    public async Task<List> GetAllPartsAsync()
    {
    var parts = new List();
    using var connection = new NpgsqlConnection(_connectionString);
    await connection.OpenAsync();
    using var cmd = new NpgsqlCommand(
    "SELECT id, name, article, manufacturer, price, stock, description FROM parts ORDER BY id",
    connection);
    await using var reader = await cmd.ExecuteReaderAsync();
    while (await reader.ReadAsync())
    {
    parts.Add(new Part
    {
    Id = reader.GetInt32(0),
    Name = reader.GetString(1),
    Article = reader.GetString(2),
    Manufacturer = reader.GetString(3),
    Price = reader.GetDecimal(4),
    Stock = reader.GetInt32(5),
    Description = reader.IsDBNull(6) ? null : reader.GetString(6)
    });
    }
    return parts;
    }
    // ЗАДАЧА №9: Попытка добавить деталь с проверкой уникальности
    public (bool Ok, string? Error) TryAddPart(Part part)
    {
    using var connection = new NpgsqlConnection(_connectionString);
    connection.Open();
    try
    {
    using var cmd = new NpgsqlCommand(@"
    INSERT INTO parts (name, article, manufacturer, price, stock, description)
    VALUES (@name, @article, @manufacturer, @price, @stock, @description);", connection);
    cmd.Parameters.AddWithValue("@name", part.Name);
    cmd.Parameters.AddWithValue("@article", part.Article);
    cmd.Parameters.AddWithValue("@manufacturer", part.Manufacturer);
    cmd.Parameters.AddWithValue("@price", part.Price);
    cmd.Parameters.AddWithValue("@stock", part.Stock);
    cmd.Parameters.AddWithValue("@description", (object?)part.Description ?? DBNull.Value);
    cmd.ExecuteNonQuery();
    return (true, null);
    }
    catch (PostgresException ex) when (ex.SqlState == "23505")
    {
    return (false, "Запчасть с таким артикулом уже существует.");
    }
    catch (Exception ex)
    {
    return (false, $"Непредвиденная ошибка: {ex.Message}");
    }
    }
    }