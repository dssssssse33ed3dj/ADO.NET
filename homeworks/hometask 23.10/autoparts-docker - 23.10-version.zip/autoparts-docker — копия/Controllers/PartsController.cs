using Microsoft.AspNetCore.Mvc;
using AutoPartsApp.Data;
using AutoPartsApp.Models;

namespace AutoPartsApp.Controllers;

public class PartsController : Controller
{
    private readonly DbHelper _db;

    public PartsController(DbHelper db)
    {
        _db = db;
    }



    // GET /Parts/Details/5
    public IActionResult Details(int id)
    {
        var part = _db.GetPartById(id);
        if (part == null) return NotFound();
        return View(part);
    }

    // GET /Parts/Create
    public IActionResult Create() => View();

  // Изменено для Задачи №9: Безопасное добавление с перехватом дубликатов артикула
// POST /Parts/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Part part)
    {
    if (ModelState.IsValid)
    {
        var result = _db.TryAddPart(part);
        if (result.Ok)
        {
            return RedirectToAction(nameof(Index));
        }
        
        // Передаем ошибку СУБД напрямую в валидацию конкретного поля формы
        ModelState.AddModelError("Article", result.Error ?? "Ошибка базы данных.");
    }
    return View(part);
}

    // POST /Parts/Buy/5
    [HttpPost]
    public IActionResult Buy(int id, int quantity = 1)
    {
        var success = _db.DecreaseStock(id, quantity);
        TempData["Message"] = success
            ? $"Запчасть куплена! Остаток уменьшен на {quantity}."
            : "Недостаточно запчастей на складе.";
        return RedirectToAction(nameof(Index));
    }

    //  ЗАДАЧА №1 (МЕТОД СТРОГО ВНУТРИ КЛАССА PARTSCONTROLLER)
    // GET /Parts/Search
    public IActionResult Search(string query)
    {
        var parts = _db.SearchParts(query);
        ViewBag.Query = query; 
        return View("Index", parts); 
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Delete([FromForm] int id)
{
    bool isDeleted = _db.DeletePart(id);

    if (isDeleted)
        TempData["SuccessMessage"] = "Запчасть успешно удалена!";
    else
        TempData["ErrorMessage"] = "Ошибка: Запчасть для удаления не найдена.";

    return RedirectToAction(nameof(Index));
}

// Добавлено из Задачи №3: Просмотр статистики склада
// GET /Parts/Stats
public IActionResult Stats()
{
    var stats = _db.GetStats();
    return View(stats);
}

// Добавлено из Задачи №4: Оформление заказа через транзацию
// POST /Parts/Order
// GET /Parts/Order?id=3&quantity=1
[HttpGet]
public IActionResult Order(int id, int quantity = 1)
{
    var success = _db.PlaceOrder(id, quantity);
    TempData["Message"] = success
        ? $"Заказ успешно оформлен через транзакцию! Создана запись в таблице заказов."
        : "Ошибка оформления заказа: Недостаточно товара на складе.";
    return RedirectToAction(nameof(Index));
}




// Добавлено из Задачи №5: Массовое пополнение склада
// GET /Parts/Restock?data=1:10,3:20
[HttpGet]
public IActionResult Restock(string data)
{
    if (string.IsNullOrWhiteSpace(data))
    {
        TempData["ErrorMessage"] = "Ошибка: Данные поступления пусты.";
        return RedirectToAction(nameof(Index));
    }

    var itemsList = new List<System.ValueTuple<int, int>>();
    try
    {
        var pairs = data.Split(',');
        foreach (var pair in pairs)
        {
            var parts = pair.Split(':');
            if (parts.Length == 2 && int.TryParse(parts[0], out int id) && int.TryParse(parts[1], out int qty))
            {
                if (id > 0 && qty > 0) itemsList.Add((id, qty));
            }
        }
    }
    catch
    {
        TempData["ErrorMessage"] = "Ошибка: Неверный формат данных.";
        return RedirectToAction(nameof(Index));
    }

    if (itemsList.Count == 0)
    {
        TempData["ErrorMessage"] = "Ошибка: Не заполнено ни одно поле.";
        return RedirectToAction(nameof(Index));
    }

    // Передаем массив на бэкенд
    bool success = _db.Restock(itemsList.ToArray());
    if (success)
        TempData["SuccessMessage"] = "Склад успешно пополнен! Все позиции обновлены.";
    else
        TempData["ErrorMessage"] = "Ошибка транзакции: Один или несколько ID деталей не найдены. Ничего не изменено.";

    return RedirectToAction(nameof(Index));
}

// Добавлено из Задачи №6: Просмотр сырых данных ридера
// GET /Parts/Raw
public IActionResult Raw()
{
    var rawParts = _db.GetRawParts();
    return View(rawParts);
}

// Добавлено из Задачи №7: Просмотр DataTable
// GET /Parts/Table
public IActionResult Table()
{
    var dt = _db.GetPartsDataTable();
    return View(dt);
}

// Изменено для Задачи №8: Асинхронный базовый экшен каталога
// GET /Parts
public async Task<IActionResult> Index()
{
    var parts = await _db.GetAllPartsAsync();
    return View(parts);
}

} 
